# PAIR KBS companion software

Companion software for PAIR: Verifiable quantitative knowledge and model comparison from incomplete experimental references.

The original verification and scoring implementations are included unchanged.
The KBS paper and matching manuscript sources are available at:
https://github.com/zhurunze44-hash/PAIR-IS-R9-reproducibility

From this directory:

    python3 -m pip install -r requirements-verified.txt
    bash scripts/run_constructed_checks.sh
    PYTHONPATH=reproduction python3 -m unittest discover -s reproduction -p 'test_*.py' -v
    python3 reproduction/original_scorers/verify_scorer_source.py

For original-data replay, follow reproduction/README.md and reproduction/original_scorers/README.md with the corresponding original inputs. Historical receipts and source pins retain their original versions.
